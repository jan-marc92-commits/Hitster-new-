window.HITSTER_CONFIG = {
  // Trage hier die Client-ID deiner Spotify Developer App ein.
  spotifyClientId: "DEINE_SPOTIFY_CLIENT_ID",

  // Zufälliger Startbereich:
  minStartSeconds: 20,
  secondsBeforeEnd: 35,

  // Optional: maximale Startposition in Prozent der Songdauer.
  // 0.80 bedeutet: nie später als bei 80 % des Songs starten.
  maxStartFraction: 0.80,

  playerName: "Mein Hitster"
};
