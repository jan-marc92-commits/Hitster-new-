from pathlib import Path
import pandas as pd
import qrcode
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase.pdfmetrics import stringWidth
import io, sys

# EINMAL ANPASSEN:
BASE_URL = "https://DEINE-DOMAIN.DE/"
CSV_FILE = "Hitster_.csv"
OUTPUT_PDF = "Hitster_Karten_mit_WebApp.pdf"

df = pd.read_csv(CSV_FILE)
df.columns = [str(c).lstrip("\ufeff") for c in df.columns]

PAGE_W, PAGE_H = A4
cols, rows = 3, 3
margin_x, margin_y = 24, 24
gap = 6
card_w = (PAGE_W - 2*margin_x - (cols-1)*gap) / cols
card_h = (PAGE_H - 2*margin_y - (rows-1)*gap) / rows
cards_per_page = cols * rows

def fit(text, max_width, font="Helvetica-Bold", max_size=14, min_size=7):
    text = str(text)
    size = max_size
    while size > min_size and stringWidth(text, font, size) > max_width:
        size -= 0.5
    return size

def qr_for(url):
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=4)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    b = io.BytesIO()
    img.save(b, "PNG")
    b.seek(0)
    return ImageReader(b), b

def pos(slot, mirrored=False):
    r = slot // cols
    col = slot % cols
    dc = cols - 1 - col if mirrored else col
    x = margin_x + dc * (card_w + gap)
    y = PAGE_H - margin_y - (r + 1) * card_h - r * gap
    return x, y

c = canvas.Canvas(OUTPUT_PDF, pagesize=A4)
buffers = []

for start in range(0, len(df), cards_per_page):
    batch = df.iloc[start:start+cards_per_page]

    # Vorderseiten: QR -> Web-App
    for slot, (idx, row) in enumerate(batch.iterrows()):
        x, y = pos(slot, False)
        c.rect(x, y, card_w, card_h)
        song_no = idx + 1
        url = f"{BASE_URL.rstrip('/')}/?song={song_no:03d}"
        img, buf = qr_for(url)
        buffers.append(buf)
        s = min(card_w, card_h) * 0.72
        c.drawImage(img, x+(card_w-s)/2, y+(card_h-s)/2, s, s, mask="auto")
    c.showPage()

    # Rückseiten: Interpret / Jahr / Titel
    for slot, (_, row) in enumerate(batch.iterrows()):
        x, y = pos(slot, True)
        c.rect(x, y, card_w, card_h)
        artist = str(row["Artist Name(s)"]).strip()
        title = str(row["Track Name"]).strip()
        date = str(row["Release Date"]).strip()
        year = date[:4] if len(date) >= 4 else date

        c.setFont("Helvetica-Bold", fit(artist, card_w-18))
        c.drawCentredString(x+card_w/2, y+card_h-30, artist)

        c.setFont("Helvetica-Bold", 34)
        c.drawCentredString(x+card_w/2, y+card_h/2-11, year)

        c.setFont("Helvetica-Bold", fit(title, card_w-18))
        c.drawCentredString(x+card_w/2, y+22, title)
    c.showPage()

c.save()
print(f"Erstellt: {OUTPUT_PDF}")
