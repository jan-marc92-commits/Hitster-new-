# Mein Hitster - private Spotify-Web-App

Dieses Projekt enthält deine 120 Songs und eine kleine Web-App, die nach dem Scannen einer Karte:
1. den richtigen Spotify-Titel auswählt,
2. einen zufälligen Startpunkt innerhalb des Songs bestimmt,
3. den Titel über Spotify startet,
4. auf der Spielseite weder Interpret noch Titel verrät.

## Voraussetzung
- Spotify Premium für den Account, der die Musik abspielt.
- Eine Spotify Developer App.
- Eine öffentlich erreichbare HTTPS-Adresse für diese Dateien.

## 1. Spotify Developer App anlegen
1. Öffne das Spotify Developer Dashboard und erstelle eine App.
2. Kopiere die Client ID.
3. Trage die Client ID in `config.js` bei `spotifyClientId` ein.
4. Als Redirect URI trägst du EXAKT die öffentliche Basisadresse der App ein.
   Beispiel: `https://deinname.github.io/mein-hitster/`
   Wichtig: Die URI muss exakt zur Adresse passen, unter der `index.html` liegt.

Die App verwendet Authorization Code mit PKCE. Es wird kein Client Secret im Browser gespeichert.

## 2. Dateien hosten
Geeignet sind z. B. GitHub Pages, Netlify oder Vercel.
Lade den gesamten Inhalt dieses Ordners hoch.

## 3. Karten erzeugen
Öffne `generate_cards.py` und ändere:
`BASE_URL = "https://DEINE-DOMAIN.DE/"`

Dann:
`pip install -r requirements.txt`
`python generate_cards.py`

Die erzeugte PDF heißt:
`Hitster_Karten_mit_WebApp.pdf`

## Bedienung
- QR-Code scannen.
- Beim ersten Mal mit Spotify verbinden.
- Danach auf "Song starten" tippen.
- Der Song startet an einer zufälligen Stelle.
- "Pause" stoppt die Runde.

## Zufallsbereich einstellen
In `config.js`:
- `minStartSeconds`: frühester möglicher Start.
- `secondsBeforeEnd`: Sicherheitsabstand zum Songende.
- `maxStartFraction`: z. B. 0.80 = maximal bis 80 % der Songdauer.

## Hinweise
- Auf iPhone/iPad ist wegen Browser-/Spotify-Beschränkungen ein Tippen auf "Song starten" erforderlich.
- Development-Mode-Apps von Spotify sind aktuell auf wenige autorisierte Nutzer begrenzt. Für diese private Lösung reicht normalerweise ein einziger Premium-Account, der die Musik abspielt.
- Die QR-Codes funktionieren erst endgültig, wenn `BASE_URL` auf deine echte Webadresse gesetzt wurde.


## Als App auf dem iPhone installieren
Nach dem Hochladen der Web-App:
1. Öffne die App-Adresse in Safari.
2. Tippe auf Teilen.
3. Wähle „Zum Home-Bildschirm“.
4. Danach erscheint „Hitster“ wie eine normale App auf dem iPhone.

Die App ist als PWA vorbereitet (`manifest.webmanifest` + Service Worker).
