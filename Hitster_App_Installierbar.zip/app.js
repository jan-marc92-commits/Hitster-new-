(() => {
  const cfg = window.HITSTER_CONFIG || {};
  const statusEl = document.getElementById("status");
  const errorEl = document.getElementById("error");
  const loginBtn = document.getElementById("loginBtn");
  const playBtn = document.getElementById("playBtn");
  const stopBtn = document.getElementById("stopBtn");

  let songs = [];
  let selectedSong = null;
  let player = null;
  let deviceId = null;

  const scopes = [
    "streaming",
    "user-modify-playback-state",
    "user-read-playback-state"
  ].join(" ");

  const redirectUri = window.location.origin + window.location.pathname;
  const qs = new URLSearchParams(window.location.search);

  function show(el, yes = true) { el.classList.toggle("hidden", !yes); }
  function setStatus(msg) { statusEl.textContent = msg; }
  function showError(err) {
    errorEl.textContent = typeof err === "string" ? err : (err?.message || String(err));
    show(errorEl, true);
  }

  function randomString(length = 64) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
    const values = new Uint32Array(length);
    crypto.getRandomValues(values);
    return Array.from(values, v => chars[v % chars.length]).join("");
  }

  async function sha256(text) {
    return crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  }

  function base64url(buffer) {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)))
      .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  function getToken() {
    const raw = localStorage.getItem("hitster_token");
    if (!raw) return null;
    const token = JSON.parse(raw);
    if (!token.access_token || Date.now() >= token.expires_at) return null;
    return token.access_token;
  }

  async function refreshTokenIfNeeded() {
    const raw = localStorage.getItem("hitster_token");
    if (!raw) return null;
    const token = JSON.parse(raw);
    if (token.access_token && Date.now() < token.expires_at - 60000) return token.access_token;
    if (!token.refresh_token) return null;

    const body = new URLSearchParams({
      client_id: cfg.spotifyClientId,
      grant_type: "refresh_token",
      refresh_token: token.refresh_token
    });

    const r = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {"Content-Type":"application/x-www-form-urlencoded"},
      body
    });
    if (!r.ok) return null;
    const next = await r.json();
    const merged = {
      ...token,
      ...next,
      refresh_token: next.refresh_token || token.refresh_token,
      expires_at: Date.now() + (next.expires_in * 1000)
    };
    localStorage.setItem("hitster_token", JSON.stringify(merged));
    return merged.access_token;
  }

  async function login() {
    if (!cfg.spotifyClientId || cfg.spotifyClientId.includes("DEINE_")) {
      throw new Error("Bitte zuerst in config.js deine Spotify Client-ID eintragen.");
    }

    if (selectedSong) sessionStorage.setItem("pending_song", selectedSong.id);

    const verifier = randomString(64);
    const challenge = base64url(await sha256(verifier));
    sessionStorage.setItem("pkce_verifier", verifier);

    const state = randomString(24);
    sessionStorage.setItem("oauth_state", state);

    const p = new URLSearchParams({
      client_id: cfg.spotifyClientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: scopes,
      code_challenge_method: "S256",
      code_challenge: challenge,
      state
    });
    window.location.href = "https://accounts.spotify.com/authorize?" + p.toString();
  }

  async function handleCallback() {
    const code = qs.get("code");
    if (!code) return;

    const returnedState = qs.get("state");
    const expectedState = sessionStorage.getItem("oauth_state");
    if (!expectedState || returnedState !== expectedState) throw new Error("Spotify-Anmeldung konnte nicht verifiziert werden.");

    const verifier = sessionStorage.getItem("pkce_verifier");
    const body = new URLSearchParams({
      client_id: cfg.spotifyClientId,
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
      code_verifier: verifier
    });

    const r = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {"Content-Type":"application/x-www-form-urlencoded"},
      body
    });
    if (!r.ok) throw new Error("Spotify-Anmeldung fehlgeschlagen.");
    const token = await r.json();
    token.expires_at = Date.now() + token.expires_in * 1000;
    localStorage.setItem("hitster_token", JSON.stringify(token));

    const pending = sessionStorage.getItem("pending_song");
    const clean = pending ? `${window.location.pathname}?song=${encodeURIComponent(pending)}` : window.location.pathname;
    history.replaceState({}, "", clean);
  }

  async function ensureSpotifyPlayer() {
    let token = await refreshTokenIfNeeded();
    if (!token) throw new Error("Bitte erneut mit Spotify verbinden.");

    if (player && deviceId) return deviceId;

    await new Promise((resolve, reject) => {
      const start = () => {
        player = new Spotify.Player({
          name: cfg.playerName || "Mein Hitster",
          getOAuthToken: async cb => cb(await refreshTokenIfNeeded()),
          volume: 0.9
        });

        player.addListener("ready", ({device_id}) => {
          deviceId = device_id;
          resolve();
        });
        player.addListener("authentication_error", ({message}) => reject(new Error(message)));
        player.addListener("account_error", ({message}) => reject(new Error(message)));
        player.addListener("initialization_error", ({message}) => reject(new Error(message)));
        player.addListener("playback_error", ({message}) => reject(new Error(message)));

        player.connect().catch(reject);
      };

      if (window.Spotify) start();
      else window.onSpotifyWebPlaybackSDKReady = start;
    });

    return deviceId;
  }

  function chooseRandomPosition(song) {
    const min = Math.max(0, Number(cfg.minStartSeconds || 20) * 1000);
    const beforeEnd = Math.max(15000, Number(cfg.secondsBeforeEnd || 35) * 1000);
    const fraction = Math.min(0.95, Math.max(0.2, Number(cfg.maxStartFraction || 0.8)));

    const maxByEnd = song.durationMs - beforeEnd;
    const maxByFraction = song.durationMs * fraction;
    const max = Math.max(min, Math.min(maxByEnd, maxByFraction));

    if (max <= min) return Math.max(0, Math.floor(song.durationMs * 0.25));

    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    const unit = array[0] / 0xffffffff;
    return Math.floor(min + unit * (max - min));
  }

  async function api(path, options = {}) {
    const token = await refreshTokenIfNeeded();
    if (!token) throw new Error("Spotify-Anmeldung ist abgelaufen.");
    const r = await fetch("https://api.spotify.com/v1" + path, {
      ...options,
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });
    if (!r.ok && r.status !== 204) {
      const txt = await r.text();
      throw new Error(`Spotify-Fehler ${r.status}: ${txt}`);
    }
    return r;
  }

  async function playSong() {
    if (!selectedSong) throw new Error("Keine gültige Karte erkannt.");

    setStatus("Spotify wird vorbereitet …");
    show(playBtn, false);
    show(stopBtn, false);

    // Important for Safari/iOS: call activateElement from a user gesture.
    if (player?.activateElement) {
      try { await player.activateElement(); } catch (_) {}
    }

    const id = await ensureSpotifyPlayer();
    if (player?.activateElement) {
      try { await player.activateElement(); } catch (_) {}
    }

    const positionMs = chooseRandomPosition(selectedSong);

    await api(`/me/player/play?device_id=${encodeURIComponent(id)}`, {
      method: "PUT",
      body: JSON.stringify({
        uris: [selectedSong.spotifyUri],
        position_ms: positionMs
      })
    });

    setStatus("Song läuft. Jetzt raten!");
    show(stopBtn, true);
  }

  async function pauseSong() {
    try {
      if (player) await player.pause();
      else await api("/me/player/pause", {method:"PUT"});
      setStatus("Pausiert.");
      show(stopBtn, false);
      show(playBtn, true);
    } catch (e) { showError(e); }
  }

  async function init() {
    try {
      const r = await fetch("songs.json", {cache:"no-store"});
      songs = await r.json();

      await handleCallback();

      const songId = new URLSearchParams(window.location.search).get("song")
        || sessionStorage.getItem("pending_song");
      selectedSong = songs.find(s => s.id === songId);

      if (!selectedSong) {
        setStatus("Ungültiger oder fehlender Karten-Code.");
        return;
      }

      if (getToken() || await refreshTokenIfNeeded()) {
        setStatus("Karte erkannt. Tippe auf „Song starten“.");
        show(playBtn, true);
      } else {
        setStatus("Karte erkannt. Einmalig mit Spotify verbinden.");
        show(loginBtn, true);
      }
    } catch (e) {
      showError(e);
      setStatus("Es ist ein Fehler aufgetreten.");
    }
  }

  loginBtn.addEventListener("click", () => login().catch(showError));
  playBtn.addEventListener("click", () => playSong().catch(e => {
    showError(e);
    setStatus("Song konnte nicht gestartet werden.");
    show(playBtn, true);
  }));
  stopBtn.addEventListener("click", pauseSong);

  init();
})();
